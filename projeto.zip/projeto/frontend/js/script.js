const API_URL = "http://localhost:3000/api/negocios";

async function carregarNegocios() {
const lista = document.getElementById("lista");

if (!lista) {
    return;
}

try {
    const resposta = await fetch(API_URL);
    const dados = await resposta.json();

    lista.innerHTML = "";

    dados.forEach(function(item) {
        const card = document.createElement("div");
        card.className = "card";

        const titulo = document.createElement("h3");
        titulo.textContent = item.nome;

        const categoria = document.createElement("p");
        categoria.textContent = "Categoria: " + item.categoria;

        const promocao = document.createElement("p");
        promocao.textContent = item.promocao;

        card.appendChild(titulo);
        card.appendChild(categoria);
        card.appendChild(promocao);

        lista.appendChild(card);
    });

} catch (erro) {
    console.log(erro);
}


}

const formulario = document.getElementById("form");

if (formulario) 
formulario.addEventListener("submit", async function(event) {
event.preventDefault();


    const nome = document.getElementById("nome").value;
    const categoria = document.getElementById("categoria").value;
    const promocao = document.getElementById("promocao").value;

    await fetch(API_URL, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            nome: nome,
            categoria: categoria,
            promocao: promocao
        })
    });

    formulario.reset();
    carregarNegocios();
});
carregarNegocios();
