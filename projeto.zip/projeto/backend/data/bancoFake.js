const negocios = [
    {
        nome: "Mercadinho Bahia",
        categoria: "Mercado",
        promocao: "Arroz 20% OFF"
    },
    {
        nome: "Barbearia Centro",
        categoria: "Serviço",
        promocao: "Corte + Barba por 25 reais"
    }
]

module.exports = negocios