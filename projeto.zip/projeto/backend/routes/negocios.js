const express = require('express')
const router = express.Router()

const {
    listarNegocios,
    criarNegocio
} = require('../controllers/negocioController')

router.get('/negocios', listarNegocios)
router.post('/negocios', criarNegocio)

module.exports = router