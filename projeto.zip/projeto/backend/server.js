const express = require('express')
const cors = require('cors')
const negocioRoutes = require('./routes/negocios')

const app = express()

app.use(cors())
app.use(express.json())

app.use('/api', negocioRoutes)

app.listen(3000, () => {
    console.log('Servidor rodando em http://localhost:3000')
})