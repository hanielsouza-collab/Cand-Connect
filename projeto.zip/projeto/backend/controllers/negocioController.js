const negocios = require('../data/bancoFake')

const listarNegocios = (req, res) => {
    res.json(negocios)
}

const criarNegocio = (req, res) => {
    const novoNegocio = req.body

    negocios.push(novoNegocio)

    res.status(201).json({
        mensagem: 'Negócio cadastrado',
        dados: novoNegocio
    })
}

module.exports = {
    listarNegocios,
    criarNegocio
}